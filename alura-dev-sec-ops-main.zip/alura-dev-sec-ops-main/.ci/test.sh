#!/bin/sh

cat $1 | grep "Hello, DevSecOps"
