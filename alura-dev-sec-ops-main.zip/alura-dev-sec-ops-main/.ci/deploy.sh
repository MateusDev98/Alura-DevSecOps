#!/bin/sh

echo "Deploying the code $1"
echo $(md5sum $1)
