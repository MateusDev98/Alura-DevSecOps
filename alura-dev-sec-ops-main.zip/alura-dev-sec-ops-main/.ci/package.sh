#!/bin/sh

zip artifact.zip $1
