#!/bin/sh

cat $1
