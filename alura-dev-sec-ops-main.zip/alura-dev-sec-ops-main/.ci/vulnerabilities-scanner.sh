#!/bin/sh
echo "Checking for vulnerabilities in the directory $(pwd)"
